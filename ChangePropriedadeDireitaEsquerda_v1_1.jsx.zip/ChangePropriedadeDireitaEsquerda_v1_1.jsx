#target "indesign"

// Função para alterar a direção do texto em todos os estilos de parágrafo
// Renato Akira dos Santos v1.1
function changeAllParagraphStylesDirection(doc) {
    // Itera por todos os estilos de parágrafo no documento
    for (var i = 0; i < doc.allParagraphStyles.length; i++) {
        var paragraphStyle = doc.allParagraphStyles[i];

        // Verifica se o estilo de parágrafo é válido
        if (paragraphStyle.isValid) {
            try {
                // Altera a direção do texto para Left to Right
                paragraphStyle.paragraphDirection = ParagraphDirectionOptions.LEFT_TO_RIGHT_DIRECTION;
                $.writeln("Alterado: " + paragraphStyle.name);
            } catch (e) {
                // Caso ocorra um erro, loga a mensagem de erro
                $.writeln("Erro ao alterar o estilo: " + paragraphStyle.name + ", " + e.message);
            }
        }
    }
}

// Verifica se há documentos abertos
if (app.documents.length > 0) {
    var doc = app.activeDocument;

    // Chama a função para alterar a direção de todos os estilos de parágrafo
    changeAllParagraphStylesDirection(doc);

    // Exibe uma mensagem de conclusão
    alert("A direção de todos os estilos de parágrafo foi alterada para 'Left to Right'.");
} else {
    alert("Por favor, abra um documento no InDesign para executar o script.");
}
